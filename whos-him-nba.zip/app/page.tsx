import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import LeBronCareerPlot from './components/lebron-career-plot'

export default function Home() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold mb-4">Welcome to Who's Him NBA</h1>
        <p className="text-xl mb-6">Creating The Best Algorithms, Statistics & Analytics Website For The Best Sport</p>
        <p className="text-lg mb-8">
          Who's Him NBA is your ultimate destination for in-depth NBA analytics, cutting-edge statistics, and expert insights. 
          We combine advanced data analysis with a passion for basketball to bring you unparalleled perspectives on player performance, 
          team strategies, and league trends.
        </p>
      </section>

      <Link href="/masbos">
        <section className="bg-primary text-primary-foreground rounded-lg p-6 hover:bg-primary/90 transition-colors cursor-pointer">
          <h2 className="text-2xl font-bold mb-4">Introducing MASBOS</h2>
          <p className="text-lg">
            Our proprietary advanced statistic: <strong>Mixture of Advanced Stats and Betting Odds Score (MASBOS)</strong>. 
            MASBOS combines traditional advanced stats with real-time betting odds to provide a unique and comprehensive 
            player evaluation metric. Stay ahead of the game with our innovative approach to NBA analytics.
          </p>
        </section>
      </Link>

      <LeBronCareerPlot />

      <section>
        <h2 className="text-3xl font-bold mb-4">Explore Our Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>MVP Race</CardTitle>
              <CardDescription>Track the top contenders for the Most Valuable Player award.</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/mvp">
                <Button className="w-full">View MVP Race</Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>DPOY Race</CardTitle>
              <CardDescription>Follow the best defenders competing for Defensive Player of the Year.</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dpoy">
                <Button className="w-full">View DPOY Race</Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>6th Man Race</CardTitle>
              <CardDescription>Discover the top bench players making a big impact this season.</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/sixth-man">
                <Button className="w-full">View 6th Man Race</Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>MASBOS Leaders</CardTitle>
              <CardDescription>See who's leading in our advanced MASBOS metric.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full">Coming Soon</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-4">Additional Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>File Sharing</CardTitle>
              <CardDescription>Share and access NBA datasets</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Upload your own NBA datasets or purchase datasets from other users. Collaborate and enhance your analysis with shared data.</p>
              <Link href="/file-sharing">
                <Button className="w-full">Explore Datasets</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Research</CardTitle>
              <CardDescription>Deep dive into NBA analytics</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Access in-depth research articles and analytical pieces on various NBA topics. Stay updated with the latest trends and insights.</p>
              <Link href="/research">
                <Button className="w-full">Read Research</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Player Traits</CardTitle>
              <CardDescription>Discover player specialties</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Explore detailed breakdowns of player skills and traits. Find out who excels in specific areas of the game.</p>
              <Link href="/player-traits">
                <Button className="w-full">View Player Traits</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Comparisons</CardTitle>
              <CardDescription>Head-to-head player analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Compare any two NBA players across various statistical categories. Settle debates with data-driven insights.</p>
              <Link href="/comparisons">
                <Button className="w-full">Compare Players</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-4">Betting Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Live Injury Report</CardTitle>
              <CardDescription>Stay updated on player injuries</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Get real-time updates on NBA player injuries and status changes. Make informed betting decisions with the latest information.</p>
              <Link href="/betting/live-injury-report">
                <Button className="w-full">View Injury Report</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Arbitrage Calculator</CardTitle>
              <CardDescription>Maximize your betting profits</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Calculate potential arbitrage opportunities across different bookmakers. Optimize your bets for guaranteed profits.</p>
              <Link href="/betting/arbitrage-calculator">
                <Button className="w-full">Use Calculator</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>No-Viggs Calculator</CardTitle>
              <CardDescription>Remove the bookmaker's edge</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Convert standard odds to no-vig probabilities and fair odds. Understand the true implied probabilities of betting markets.</p>
              <Link href="/betting/no-viggs">
                <Button className="w-full">Calculate No-Vig Odds</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Expected Value Calculator</CardTitle>
              <CardDescription>Evaluate bet profitability</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Calculate the expected value of your bets based on probabilities and potential payouts. Make smarter betting decisions.</p>
              <Link href="/betting/expected-value">
                <Button className="w-full">Calculate EV</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Kelly Formula Calculator</CardTitle>
              <CardDescription>Optimize your bet sizing</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Use the Kelly Criterion to determine the optimal size of your bets. Maximize long-term growth while managing risk.</p>
              <Link href="/betting/kelly-formula">
                <Button className="w-full">Calculate Kelly Criterion</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}

