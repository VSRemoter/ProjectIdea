'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Menu, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Image from 'next/image'

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const navItems = [
    { href: '/projections', label: 'Projections', subItems: [
      { href: '/mvp', label: 'MVP' },
      { href: '/dpoy', label: 'DPOY' },
      { href: '/sixth-man', label: '6MAN' },
      { href: '/projections/best-teams', label: 'Best Teams' },
      { href: '/projections/best-players', label: 'Best Players' },
      { href: '/projections/compare-betting-odds', label: 'Compare Betting Odds' },
    ]},
    { href: '/betting', label: 'Betting', subItems: [
      { href: '/live-injury-report', label: 'Live Injury Report' },
      { href: '/arbitrage-calculator', label: 'Arbitrage Calculator' },
      { href: '/no-viggs', label: 'No-Viggs Calculator' },
      { href: '/expected-value', label: 'Expected Value' },
      { href: '/betting/kelly-formula', label: 'Kelly Formula' },
    ]},
    { href: '/masbos', label: 'MASBOS', subItems: [
      { href: '/masbos', label: 'About' },
      { href: '/masbos/leaders', label: 'MASBOS Leaders' },
      { href: '/masbos/alltime', label: 'MASBOS Alltime' },
    ]},
    { href: '/guides', label: 'Guides', subItems: [
      { href: '/guides/how-to-bet', label: 'How to Bet' },
      { href: '/guides/parlays', label: 'Parlays' },
      { href: '/guides/expected-value', label: 'Expected Value' },
      { href: '/guides/over-under-betting', label: 'Over/Under Betting' },
      { href: '/guides/middling', label: 'Middling' },
      { href: '/guides/futures', label: 'Futures' },
      { href: '/guides/best-betting-exchanges', label: 'Best Betting Exchanges' },
      { href: '/guides/strategies', label: 'Strategies' },
    ]},
    { href: '/file-sharing', label: 'File Sharing' },
    { href: '/research', label: 'Research' },
    { href: '/comparisons', label: 'Comparisons' },
    { href: '/player-traits', label: 'Player Traits' },
    { href: '/about', label: 'About Me' },
    { href: '/signup', label: 'Sign Up' },
    { href: '/login', label: 'Login' },
  ]

  return (
    <nav className="bg-primary text-primary-foreground shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2">
            <Image 
              src="/logo.png" 
              alt="Who's Him NBA Logo" 
              width={32} 
              height={32} 
              className="dark:invert"
            />
            <span className="text-xl font-bold">Who's Him NBA</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-4 items-center">
            {navItems.map((item) => (
              item.subItems ? (
                <DropdownMenu key={item.href}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="p-0 font-normal text-base hover:text-secondary">
                      {item.label}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {item.subItems.map((subItem) => (
                      <DropdownMenuItem key={subItem.href}>
                        <Link href={subItem.href} className="w-full">
                          {subItem.label}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  key={item.href}
                  href={item.href}
                  className="hover:text-secondary text-base"
                >
                  {item.label}
                </Link>
              )
            ))}
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden">
            <Button variant="ghost" onClick={() => setIsOpen(!isOpen)} className="text-primary-foreground">
              {isOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isOpen && (
          <div className="md:hidden">
            {navItems.map((item) => (
              item.subItems ? (
                <div key={item.href}>
                  <span className="block py-2 font-bold">{item.label}</span>
                  {item.subItems.map((subItem) => (
                    <Link
                      key={subItem.href}
                      href={subItem.href}
                      className="block py-2 pl-4 hover:text-secondary"
                      onClick={() => setIsOpen(false)}
                    >
                      {subItem.label}
                    </Link>
                  ))}
                </div>
              ) : (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`block py-2 ${
                    pathname === item.href ? 'font-bold' : ''
                  } hover:text-secondary`}
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </Link>
              )
            ))}
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navigation

